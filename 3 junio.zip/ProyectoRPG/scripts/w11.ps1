reg delete "HKCU\Console" /v DelegationConsole /f
reg delete "HKCU\Console\%%Startup" /v DelegationConsole /f